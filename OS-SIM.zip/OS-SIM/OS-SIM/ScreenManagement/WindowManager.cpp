#include "WindowManager.h"

WindowManager Window = { NULL, NULL, NULL };